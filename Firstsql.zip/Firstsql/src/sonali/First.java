package sonali;

import java.sql.DriverManager;
import java.util.Scanner;

import com.mysql.jdbc.Connection;

public class First {

	public static void main(String[] args) throws Exception {
		
		char ch;
		while(1)
		{
			System.out.println("\n1.ADD BOOK");
			System.out.println("\n2.EDIT BOOK");
			System.out.println("\n3.DELETE BOOK");
			System.out.println("\n4.VIEW BOOKS");
			System.out.println("\n5.ISSUING BOOK");
			System.out.println("\n6.VIEW ISSUED BOOK");
			System.out.println("\n7.RETURN NOOKS");
			System.out.println("\n8.TO LOGOUT");
			System.out.println("\nEnter your Choice(1-8)");
			Scanner sc=new Scanner(System.in);
			int n=sc.nextInt();
			
			switch(n)
			{
			case 1:AddBook();
			   break;
			
			}
			
			
			
		}
		
		
		
					

	}

	private static void AddBook() {
		// TODO Auto-generated method stub
		
	}

	
	

}
