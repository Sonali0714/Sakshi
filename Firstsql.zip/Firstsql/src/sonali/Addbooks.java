package sonali;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.jdbc.Statement;



public class Addbooks {

	

	
	public static void main(String[] args) throws Exception {
		
			Class.forName("com.mysql.jdbc.Driver");
		
		
			Connection c =DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","11228899");
		
		System.out.println("Connected" +c);
		
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter BookName:");
			String bn=sc.nextLine();
			System.out.println("Enter BookAuthor:");
			String ba=sc.nextLine();
			System.out.println("Enter Edition:");
			String bee=sc.nextLine();
			int be=Integer.parseInt(bee);
			
			
			
			String s="select *from Adbooks";
			
			
			
			Statement st= (Statement) c.createStatement();
			
			ResultSet rs=st.executeQuery(s);
			int Avail=0;
			
			while(rs.next())
			{
				String BookName=rs.getString("BookName");
				String BookAuthor=rs.getString("Author");
				
				
				if(bn.equalsIgnoreCase(BookName) && ba.equalsIgnoreCase(BookAuthor))
				{
					
					String s1="(Update adbooks set Avail='Avail+1' where BookName='+BookName+')";
					st.executeUpdate(s1);
				}
				else
				{
					
					String s2="INSERT INTO adbooks(BookName,Author,Edition)"+"VALUES('"+bn+"','"+ba+"',"+be+")";
					st.executeUpdate(s2);
					String s3=" Update adbooks set Avail=Avail+1 where BookName='+bn+'";
					st.executeUpdate(s3);
					
				}
			}
		}
	
		
		
		
		
		
	}

	

}
